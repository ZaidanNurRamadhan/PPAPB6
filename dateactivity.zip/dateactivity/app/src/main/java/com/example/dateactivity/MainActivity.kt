package com.example.dateactivity

import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.DatePicker
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.dateactivity.databinding.ActivityMainBinding
import com.example.dateactivity.dialog.DatePickerDialog
import com.example.dateactivity.dialog.TimePicker

class MainActivity : AppCompatActivity(),
    android.app.DatePickerDialog.OnDateSetListener,
        TimePickerDialog.OnTimeSetListener

{
    private val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        val stringGender = resources.getStringArray(R.array.gender)
        val stringCountry = listOf(
            "Indonesia","chine","korea"
        )
        with (binding){
         val adapterSpinnerGender = ArrayAdapter (this@MainActivity,
             android.R.layout.simple_spinner_item, stringGender)
            spinnergender.adapter = adapterSpinnerGender
            spinnergender.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                    Toast.makeText(this@MainActivity, stringGender.get(p2), Toast.LENGTH_SHORT).show()
                }

                override fun onNothingSelected(p0: AdapterView<*>?) {
                    TODO("Not yet implemented")
                }
            }

            datePicker.init(
                datePicker.year,
                datePicker.month,
                datePicker.dayOfMonth
            ){view,year, month, day
                -> val selectedDate = "$day/${month+1}/$year" //karna month mulai nya dari 0 bukan dari 1
                Toast.makeText(this@MainActivity, selectedDate, Toast.LENGTH_SHORT).show()
            }

            timePicker.setOnTimeChangedListener{view, hour, minute ->
                val selectedTime = String.format("%02d:%02d", hour, minute)
                Toast.makeText(this@MainActivity, selectedTime, Toast.LENGTH_SHORT).show()
            }
        }


    }
    fun showCalendar(view: View){
        val datePicker = DatePickerDialog()
        datePicker.show(supportFragmentManager, "datepicker")
    }
    fun showTimePicker(view: View){
        val timePicker = TimePicker()
        timePicker.show(supportFragmentManager,"timepicker")
    }
    fun showAlert(view: View){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("ini pesan")
        builder.setMessage("halo saya dialog")
        builder.setPositiveButton("ya"){dialog, _ ->
            finish()}
        builder.setNegativeButton("tidak"){dialog, _ ->
            dialog.dismiss()}
        val dialog = builder.create()
        dialog.show()
    }

    override fun onDateSet(p0: DatePicker?, p1: Int, p2: Int, p3: Int) {
        val selectedDate ="$p1/${p2 + 1}/$p3"
        Toast.makeText(this@MainActivity, selectedDate, Toast.LENGTH_SHORT).show()
    }

    override fun onTimeSet(p0: android.widget.TimePicker?, p1: Int, p2: Int) {
        val selectedTime = String.format("%02d:%02d",p1,p2)
        Toast.makeText(this@MainActivity, selectedTime, Toast.LENGTH_SHORT).show()
    }

}